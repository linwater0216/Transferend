#include "Shape2D.h"
Shape2D::Shape2D()
{

}
string Shape2D::toString() const
{
	return "Shape2D Object";
}