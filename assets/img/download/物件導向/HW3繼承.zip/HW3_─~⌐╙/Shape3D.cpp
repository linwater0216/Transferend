#include "Shape3D.h"
#include "Shape.h"
Shape3D::Shape3D()
{

}
string Shape3D::toString() const
{
	return "Shape3D Object";
}